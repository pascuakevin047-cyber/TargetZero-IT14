
using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D))]
public class movements : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f;

    private Rigidbody2D rb;
    private Vector2 moveInput;
    private Animator animator;

    private Vector2 lastMoveDirection = Vector2.down;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    private void Update()
    {
        moveInput = Vector2.zero;
        if (PlayerInteractionLock.IsLocked)
        {
            if (animator != null) animator.SetBool("isWalking", false);
            if (rb != null) rb.linearVelocity = Vector2.zero;
            return;
        }

        // Keyboard movement: WASD and arrow keys
        if (Keyboard.current != null)
        {
            if (Keyboard.current.aKey.isPressed ||
                Keyboard.current.leftArrowKey.isPressed)
            {
                moveInput.x -= 1f;
            }

            if (Keyboard.current.dKey.isPressed ||
                Keyboard.current.rightArrowKey.isPressed)
            {
                moveInput.x += 1f;
            }

            if (Keyboard.current.sKey.isPressed ||
                Keyboard.current.downArrowKey.isPressed)
            {
                moveInput.y -= 1f;
            }

            if (Keyboard.current.wKey.isPressed ||
                Keyboard.current.upArrowKey.isPressed)
            {
                moveInput.y += 1f;
            }
        }

        // PlayStation controller: left stick and D-pad
        if (Gamepad.current != null)
        {
            Vector2 stickInput =
                Gamepad.current.leftStick.ReadValue();

            Vector2 dpadInput =
                Gamepad.current.dpad.ReadValue();

            if (stickInput.sqrMagnitude > 0.01f)
            {
                moveInput = stickInput;
            }
            else if (dpadInput.sqrMagnitude > 0.01f)
            {
                moveInput = dpadInput;
            }
        }

        // Prevent faster diagonal movement
        moveInput = Vector2.ClampMagnitude(moveInput, 1f);

        // Remember the last movement direction
        if (moveInput.sqrMagnitude > 0.01f)
        {
            lastMoveDirection = moveInput.normalized;
        }

        // Animator parameters
        if (animator != null)
        {
            animator.SetBool(
                "isWalking",
                moveInput.sqrMagnitude > 0.01f
            );

            animator.SetFloat("InputX", moveInput.x);
            animator.SetFloat("InputY", moveInput.y);

            animator.SetFloat(
                "LastInputX",
                lastMoveDirection.x
            );

            animator.SetFloat(
                "LastInputY",
                lastMoveDirection.y
            );
        }
    }

    private void FixedUpdate()
    {
        if (rb != null)
        {
            rb.linearVelocity = PlayerInteractionLock.IsLocked ? Vector2.zero : moveInput * moveSpeed;
        }
    }
}

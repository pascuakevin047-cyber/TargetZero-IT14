using UnityEngine;

// Shared movement lock for dialogue and shopping. No scene setup required.
public static class PlayerInteractionLock
{
    public static bool IsLocked => (DialogueUI.Instance != null && DialogueUI.Instance.IsOpen()) || FoodVendor.AnyInteractionOpen || NPCDialogue.AnyMotherDialogueOpen;
}

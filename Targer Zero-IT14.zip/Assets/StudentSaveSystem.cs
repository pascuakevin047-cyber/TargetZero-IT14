
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

[Serializable]
public class StudentSaveData
{
    public string selectedCharacter = "Boy";
    public int money = 500;
    public float health = 100f;
    public float secondsUntilHealthLoss = 60f;

    public List<string> claimedNPCs = new List<string>();
}

public static class StudentSaveSystem
{
    private static string SavePath =>
        Path.Combine(
            Application.persistentDataPath,
            "student_save.json"
        );

    public static StudentSaveData Data;

    public static void Load()
    {
        if (File.Exists(SavePath))
        {
            try
            {
                string json = File.ReadAllText(SavePath);

                Data = JsonUtility.FromJson<StudentSaveData>(json);
            }
            catch (Exception e)
            {
                Debug.LogError("JSON Load Error: " + e.Message);
            }
        }

        if (Data == null)
        {
            Data = new StudentSaveData();
        }

        if (Data.claimedNPCs == null)
        {
            Data.claimedNPCs = new List<string>();
        }

        Data.money = Mathf.Max(0, Data.money);
        Data.health = Mathf.Clamp(Data.health, 0f, 100f);
        Data.secondsUntilHealthLoss = Mathf.Clamp(
            Data.secondsUntilHealthLoss, 0f, 60f
        );
    }

    public static void Save()
    {
        if (Data == null)
            return;

        try
        {
            string json = JsonUtility.ToJson(Data, true);

            File.WriteAllText(SavePath, json);

            Debug.Log("Student progress saved to JSON!");
        }
        catch (Exception e)
        {
            Debug.LogError("JSON Save Error: " + e.Message);
        }
    }

    public static void ResetData()
    {
        Data = new StudentSaveData();
        Save();
    }

    public static bool HasClaimedNPC(string npcID)
    {
        return Data.claimedNPCs.Contains(npcID);
    }

    public static void ClaimNPC(string npcID)
    {
        if (!Data.claimedNPCs.Contains(npcID))
        {
            Data.claimedNPCs.Add(npcID);
            Save();
        }
    }
}

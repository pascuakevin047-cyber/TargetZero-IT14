using UnityEngine;
using UnityEngine;
using TMPro; 

public class MoneyManager : MonoBehaviour
{
    public static MoneyManager Instance;

    [SerializeField] private int totalMoney = 0;
    [SerializeField] private TextMeshProUGUI moneyText; 

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    void Start()
    {
        UpdateMoneyUI();
    }

    public void AddMoney(int amount)
    {
        totalMoney += amount;
        UpdateMoneyUI();
    }

    private void UpdateMoneyUI()
    {
        moneyText.text = "Money:₱" + totalMoney;
    }

    public int GetMoney()
    {
        return totalMoney;
    }
    public void SetMoney(int amount)
    {
        totalMoney = amount;
        UpdateMoneyUI();
    }
}
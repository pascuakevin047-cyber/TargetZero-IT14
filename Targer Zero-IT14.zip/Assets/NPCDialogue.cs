using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

// Mother NPC: vendor-style OnGUI conversation, one allowance per Play session.
[RequireComponent(typeof(Collider2D))]
public class NPCDialogue : MonoBehaviour
{
    [Header("NPC")]
    [SerializeField] private string npcID = "Mother";
    [SerializeField] private string npcName = "Mother";
    [SerializeField] private int allowance = 150;

    private readonly HashSet<Collider2D> nearby = new HashSet<Collider2D>();
    private bool talking;
    private bool claimedThisSession;
    private bool claimedForConversation;
    private bool requireRelease;
    private int lineIndex;
    private GUIStyle titleStyle, textStyle, buttonStyle;

    public static bool AnyMotherDialogueOpen { get; private set; }

    private static readonly string[] FirstConversation =
    {
        "Good morning, sweetheart! Are you ready for school?",
        "Good morning, Mom! I'm getting ready, but can I ask for some allowance?",
        "Of course! Here's P150 for your school expenses. Spend it wisely!",
        "Thank you, Mom! I'll make sure to save some money for food.",
        "Remember to eat on time and take care of your health. Have a great day!"
    };

    private static readonly string[] RepeatConversation =
    {
        "I've already given you your allowance today, sweetheart. Remember to spend it wisely!"
    };

    private string[] Lines => claimedForConversation ? RepeatConversation : FirstConversation;

    private void Awake()
    {
        GetComponent<Collider2D>().isTrigger = true;
    }

    private bool IsPlayer(Collider2D other)
    {
        return other.CompareTag("Player") ||
               (other.attachedRigidbody != null && other.attachedRigidbody.CompareTag("Player")) ||
               other.transform.root.CompareTag("Player");
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (IsPlayer(other)) nearby.Add(other);
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if (IsPlayer(other)) nearby.Add(other);
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        nearby.Remove(other);
    }

    private void Update()
    {
        nearby.RemoveWhere(c => c == null || !c.enabled || !c.gameObject.activeInHierarchy);

        bool keyboard = Keyboard.current != null && Keyboard.current.eKey.wasPressedThisFrame;
        bool controller = Gamepad.current != null && Gamepad.current.buttonSouth.wasPressedThisFrame;
        bool held = (Keyboard.current != null && Keyboard.current.eKey.isPressed) ||
                    (Gamepad.current != null && Gamepad.current.buttonSouth.isPressed);

        if (requireRelease)
        {
            if (!held) requireRelease = false;
            return;
        }

        if (!keyboard && !controller) return;
        if (talking)
        {
            NextLine();
            return;
        }

        if (nearby.Count == 0 || FoodVendor.AnyInteractionOpen ||
            (DialogueUI.Instance != null && DialogueUI.Instance.IsOpen()) ||
            AnyMotherDialogueOpen) return;

        claimedForConversation = claimedThisSession;
        lineIndex = 0;
        talking = true;
        AnyMotherDialogueOpen = true;
        requireRelease = true;
    }

    private void NextLine()
    {
        // Grant only when the mother actually reaches her allowance line.
        if (!claimedForConversation && !claimedThisSession && lineIndex == 2)
        {
            if (MoneyHealthUI.Instance != null && MoneyHealthUI.Instance.TryAddMoney(allowance))
            {
                claimedThisSession = true;
                Debug.Log("Mother gave P" + allowance + " allowance this Play session.");
            }
            else
            {
                Debug.LogWarning("Mother could not grant allowance: check MoneyHealthUI.");
            }
        }

        lineIndex++;
        if (lineIndex >= Lines.Length) EndDialogue();
        else requireRelease = true;
    }

    public void EndDialogue()
    {
        talking = false;
        AnyMotherDialogueOpen = false;
        lineIndex = 0;
        requireRelease = true;
    }

    // Kept for compatibility with existing scripts.
    public void OnDialogueFinished() => EndDialogue();
    public void CloseInteraction() => EndDialogue();

    private void OnDisable()
    {
        nearby.Clear();
        talking = false;
        AnyMotherDialogueOpen = false;
    }

    private void EnsureStyles()
    {
        if (titleStyle != null) return;
        titleStyle = new GUIStyle(GUI.skin.label)
        {
            normal = { textColor = new Color32(35, 24, 27, 255) },
            fontSize = 22, fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleCenter, wordWrap = true
        };
        textStyle = new GUIStyle(GUI.skin.label)
        {
            normal = { textColor = new Color32(35, 24, 27, 255) },
            fontSize = 16, alignment = TextAnchor.MiddleLeft, wordWrap = true
        };
        buttonStyle = new GUIStyle(GUI.skin.button)
        {
            fontSize = 18, fontStyle = FontStyle.Bold
        };
    }

    private void OnGUI()
    {
        if (!talking && nearby.Count == 0) return;
        EnsureStyles();
        float scale = Mathf.Max(0.55f, Mathf.Min(Screen.width / 960f, Screen.height / 650f));
        Matrix4x4 previous = GUI.matrix;
        GUI.matrix = Matrix4x4.TRS(
            new Vector3((Screen.width - 960 * scale) / 2f,
                        (Screen.height - 650 * scale) / 2f, 0),
            Quaternion.identity, new Vector3(scale, scale, 1));

        if (!talking)
        {
            if (!FoodVendor.AnyInteractionOpen &&
                (DialogueUI.Instance == null || !DialogueUI.Instance.IsOpen()))
                GUI.Box(new Rect(290, 550, 380, 50), "E / CROSS  -  TALK TO MOTHER", PixelUISkin.Panel);
        }
        else
        {
            GUI.Box(new Rect(100, 410, 760, 180), "", PixelUISkin.Panel);
            bool playerSpeaking = !claimedForConversation && (lineIndex == 1 || lineIndex == 3);
            GUI.Label(new Rect(125, 430, 710, 35), playerSpeaking ? "Player" : npcName, titleStyle);
            GUI.Label(new Rect(130, 475, 700, 55), Lines[lineIndex], textStyle);
            if (GUI.Button(new Rect(650, 535, 175, 42),
                           lineIndex == Lines.Length - 1 ? "Finish" : "Next", PixelUISkin.Button))
            {
                NextLine();
            }
        }
        GUI.matrix = previous;
    }
}

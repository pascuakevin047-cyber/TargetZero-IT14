
using UnityEngine;
using Unity.Cinemachine;

public class SelectedCharacterSpawner : MonoBehaviour
{
    [Header("Character Prefabs")]
    [SerializeField] private GameObject boyPrefab;
    [SerializeField] private GameObject girlPrefab;

    [Header("Spawn Point")]
    [SerializeField] private Transform spawnPoint;

    [Header("Cinemachine 3 Camera")]
    [SerializeField] private CinemachineCamera cinemachineCamera;

    private void Start()
    {
        // Load selected character
        GameSession.LoadCharacter();

        GameObject selectedPrefab =
            GameSession.SelectedCharacter == "Girl"
                ? girlPrefab
                : boyPrefab;

        if (selectedPrefab == null)
        {
            Debug.LogError("Selected character prefab is missing!");
            return;
        }

        // Get spawn position
        Vector3 spawnPosition = spawnPoint != null
            ? spawnPoint.position
            : transform.position;

        spawnPosition.z = 0f;

        // Spawn selected character
        GameObject player = Instantiate(
            selectedPrefab,
            spawnPosition,
            Quaternion.identity
        );

        player.name = selectedPrefab.name;

        // Attach the seven-day timer to the spawned player automatically.
        // This works for both Boy and Girl without changing the scene.
        DayCountdownManager countdown = player.AddComponent<DayCountdownManager>();
        countdown.SetSpawnPoint(spawnPosition);

        // CONNECT SPAWNED PLAYER TO CINEMACHINE 3
        if (cinemachineCamera != null)
        {
            cinemachineCamera.Target.TrackingTarget =
                player.transform;

            Debug.Log("Camera Tracking Target: " + player.name);
        }
        else
        {
            Debug.LogError("Cinemachine Camera is not assigned!");
        }

        Debug.Log("Successfully spawned: " + player.name);
    }
}

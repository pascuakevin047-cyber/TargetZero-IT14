TARGET ZERO - FOOD VENDOR

1. Open Assets/Scenes/Target Zero - IT14.unity in Unity.
2. Top menu: Tools > Target Zero > Create Food Vendor In Scene.
3. Select Food Vendor in Hierarchy and move it to your desired store/shop location.
4. Save scene (Cmd+S).
5. Ensure spawned BoyPlayer and GirlPlayer have tag Player, Collider2D and Rigidbody2D.
6. Press Play, approach vendor, press E (or controller Cross/A).
7. Click Next through 3 dialogue lines. Food and drinks menu appears.
8. Click + / - beside each item, then Buy. Money and health update via MoneyHealthUI.
9. Close exits without purchasing. Escape also closes.

The 6 food/drink images are in Assets/Resources/VendorIcons.
Prices and healing are in Assets/VendorShop/FoodVendor.cs.
The menu is created at runtime using Unity IMGUI, so no Canvas setup is required.
Note: Mouse is needed for shop + / - / Buy; controller supports initiating dialogue only.
The vendor sprite is a simple starter asset; replace it with your own art anytime.
Testing Mode remains in MoneyHealthUI.cs; starting money resets to 500 per Editor Play.

BUY NOW: The purchase button is at the BOTTOM RIGHT of the shop window. Select quantity with +, then click BUY NOW. Rice Meal restores +20 health points (20% of max health); Sandwich +12, Burger +18, Water +4, Juice +8, Milk +10. Total health capped at 100. The money display updates instantly.

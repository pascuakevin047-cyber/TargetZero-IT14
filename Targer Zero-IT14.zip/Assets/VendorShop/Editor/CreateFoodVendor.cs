#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;

public static class CreateFoodVendor
{
    [MenuItem("Tools/Target Zero/Create Food Vendor In Scene")]
    public static void Create()
    {
        const string spritePath = "Assets/VendorShop/vendor.png";
        TextureImporter importer = AssetImporter.GetAtPath(spritePath) as TextureImporter;
        if (importer != null && importer.textureType != TextureImporterType.Sprite)
        {
            importer.textureType = TextureImporterType.Sprite;
            importer.spritePixelsPerUnit = 128;
            importer.SaveAndReimport();
        }
        Sprite sprite = AssetDatabase.LoadAssetAtPath<Sprite>(spritePath);
        GameObject vendor = new GameObject("Food Vendor");
        Undo.RegisterCreatedObjectUndo(vendor, "Create Food Vendor");
        SpriteRenderer renderer = vendor.AddComponent<SpriteRenderer>();
        renderer.sprite = sprite;
        renderer.sortingOrder = 10;
        CircleCollider2D trigger = vendor.AddComponent<CircleCollider2D>();
        trigger.isTrigger = true;
        trigger.radius = 1.6f;
        Rigidbody2D body = vendor.AddComponent<Rigidbody2D>();
        body.bodyType = RigidbodyType2D.Kinematic;
        body.simulated = true;
        vendor.AddComponent<FoodVendor>();
        GameObject spawn = GameObject.Find("PlayerSpawnPoint");
        vendor.transform.position = spawn != null ? spawn.transform.position + new Vector3(2.5f, 0, 0) : Vector3.zero;
        // Match the game's 2x character/world scale. UI scales independently to screen.
        vendor.transform.localScale = new Vector3(2f, 2f, 1f);
        Selection.activeGameObject = vendor;
        EditorSceneManager.MarkSceneDirty(vendor.scene);
        Debug.Log("Food Vendor created! Move it beside your shop, then save the scene (Cmd+S). Player must have Player tag and a Collider2D.");
    }
}
#endif


using System;
using System.IO;
using UnityEngine;

public static class GameSession
{
    public static string SelectedCharacter = "Boy";

    private static string SavePath =>
        Path.Combine(
            Application.persistentDataPath,
            "character_selection.json"
        );

    [Serializable]
    private class CharacterData
    {
        public string selectedCharacter;
    }

    public static void SaveCharacter(string character)
    {
        if (character != "Boy" && character != "Girl")
        {
            Debug.LogError("Invalid character selection!");
            return;
        }

        SelectedCharacter = character;

        CharacterData data = new CharacterData
        {
            selectedCharacter = character
        };

        File.WriteAllText(
            SavePath,
            JsonUtility.ToJson(data, true)
        );

        Debug.Log("Character selected: " + SelectedCharacter);
    }

    public static void LoadCharacter()
    {
        if (!File.Exists(SavePath))
        {
            SelectedCharacter = "Boy";
            return;
        }

        try
        {
            string json = File.ReadAllText(SavePath);
            CharacterData data =
                JsonUtility.FromJson<CharacterData>(json);

            if (data != null &&
                (data.selectedCharacter == "Boy" ||
                 data.selectedCharacter == "Girl"))
            {
                SelectedCharacter = data.selectedCharacter;
            }
            else
            {
                SelectedCharacter = "Boy";
            }
        }
        catch (Exception e)
        {
            Debug.LogError("Character save error: " + e.Message);
            SelectedCharacter = "Boy";
        }
    }
}

using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.InputSystem;

public class DialogueUI : MonoBehaviour
{
    public static DialogueUI Instance;

    [Header("Dialogue UI")]
    [SerializeField] private GameObject dialoguePanel;
    [SerializeField] private TMP_Text npcNameText;
    [SerializeField] private TMP_Text dialogueText;
    [SerializeField] private Button nextButton;

    private string[] currentLines;
    private int currentIndex;
    private int rewardAmount;
    private string currentNPCID;
    private bool rewardAlreadyClaimed;
    private bool isOpen;
    private NPCDialogue activeNPC;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Debug.LogError(
                "More than one DialogueUI exists.",
                this
            );

            enabled = false;
            return;
        }

        Instance = this;
    }

    private void Start()
    {
        if (dialoguePanel != null)
            dialoguePanel.SetActive(false);

        if (nextButton != null)
            nextButton.onClick.AddListener(NextLine);
    }

    public void StartDialogue(
        string npcName,
        string[] lines,
        int reward,
        string id,
        bool alreadyClaimed)
    {
        if (isOpen)
            return;

        if (dialoguePanel == null ||
            npcNameText == null ||
            dialogueText == null ||
            nextButton == null)
        {
            Debug.LogError(
                "Assign all four DialogueUI fields " +
                "on DialogueManager."
            );

            ReleaseActiveNPC();
            return;
        }

        if (lines == null || lines.Length == 0)
        {
            Debug.LogWarning(
                "This NPC has no Dialogue Lines."
            );

            ReleaseActiveNPC();
            return;
        }

        currentLines = lines;
        currentIndex = 0;
        rewardAmount = Mathf.Max(0, reward);
        currentNPCID = id;
        rewardAlreadyClaimed = alreadyClaimed;
        isOpen = true;

        npcNameText.text = npcName;
        dialogueText.text = currentLines[currentIndex];

        dialoguePanel.SetActive(true);
        nextButton.Select();

        Debug.Log(
            "Dialogue started: " + npcName +
            " | Reward: ₱" + rewardAmount +
            " | Already claimed: " + rewardAlreadyClaimed
        );
    }

    public void SetActiveNPC(NPCDialogue npc)
    {
        if (!isOpen)
            activeNPC = npc;
    }

    public bool IsOpen()
    {
        return isOpen;
    }

    private void Update()
    {
        if (isOpen && Gamepad.current != null && Gamepad.current.buttonSouth.wasPressedThisFrame)
            NextLine();
        else if (isOpen && Keyboard.current != null && Keyboard.current.eKey.wasPressedThisFrame)
            NextLine();
    }

    public void NextLine()
    {
        if (!isOpen)
            return;

        currentIndex++;

        if (currentIndex < currentLines.Length)
        {
            dialogueText.text = currentLines[currentIndex];
        }
        else
        {
            FinishDialogue();
        }
    }

    private void FinishDialogue()
    {
        if (rewardAlreadyClaimed)
        {
            Debug.Log(
                "This NPC's allowance was already claimed."
            );
        }
        else if (rewardAmount <= 0)
        {
            Debug.Log(
                "This dialogue has no money reward."
            );
        }
        else if (string.IsNullOrWhiteSpace(currentNPCID))
        {
            Debug.LogError(
                "Reward blocked: this NPC needs a unique NPC ID."
            );
        }
        else if (MoneyHealthUI.Instance == null)
        {
            Debug.LogError(
                "MoneyHealthUI is missing."
            );
        }
        else if (StudentSaveSystem.HasClaimedNPC(currentNPCID))
        {
            Debug.Log(
                "This NPC's allowance was already claimed."
            );
        }
        else
        {
            bool received =
                MoneyHealthUI.Instance.TryAddMoney(rewardAmount);

            if (received)
            {
                StudentSaveSystem.ClaimNPC(currentNPCID);
                rewardAlreadyClaimed = true;

                Debug.Log(
                    "Allowance successfully claimed from: " +
                    currentNPCID
                );
            }
        }

        isOpen = false;

        if (dialoguePanel != null)
            dialoguePanel.SetActive(false);

        ReleaseActiveNPC();
    }

    private void ReleaseActiveNPC()
    {
        if (activeNPC != null)
        {
            activeNPC.OnDialogueFinished();
            activeNPC = null;
        }
    }

    private void OnDestroy()
    {
        if (nextButton != null)
            nextButton.onClick.RemoveListener(NextLine);

        if (Instance == this)
        {
            ReleaseActiveNPC();
            Instance = null;
        }
    }
}
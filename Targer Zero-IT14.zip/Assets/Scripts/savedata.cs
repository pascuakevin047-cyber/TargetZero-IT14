[System.Serializable]
public class SaveData
{
    public int money;
    public float playerX;
    public float playerY;
}
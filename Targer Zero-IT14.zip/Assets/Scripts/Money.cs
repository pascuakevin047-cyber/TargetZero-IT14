using UnityEngine;

public class Money : MonoBehaviour
{
    [SerializeField] private int value = 10;
    [SerializeField] private AudioClip pickupSound;
    [SerializeField] [Range(0f, 1f)] private float volume = 1f;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            MoneyManager.Instance.AddMoney(value);

            if (pickupSound != null)
                AudioSource.PlayClipAtPoint(pickupSound, transform.position, volume);

            Destroy(gameObject);
        }
    }
}
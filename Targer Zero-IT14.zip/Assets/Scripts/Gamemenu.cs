using UnityEngine;
using UnityEngine.SceneManagement;

public class GameMenu : MonoBehaviour
{
    [SerializeField] private GameObject menuPanel;

    public static bool IsMenuOpen { get; private set; }

    void Start()
    {
        CloseMenu();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (IsMenuOpen)
                CloseMenu();
            else
                OpenMenu();
        }
    }

    public void OpenMenu()
    {
        menuPanel.SetActive(true);
        IsMenuOpen = true;
    }

    public void CloseMenu()
    {
        menuPanel.SetActive(false);
        IsMenuOpen = false;
    }

    public void SaveGame()
    {
        FindFirstObjectByType<SaveLoadManager>().SaveGame();
    }

    public void LoadGame()
    {
        FindFirstObjectByType<SaveLoadManager>().LoadGame();
    }

    public void QuitToMainMenu()
    {
        IsMenuOpen = false;
        SceneManager.LoadScene(0); // 0 = MainMenu scene in Build Settings
    }
}
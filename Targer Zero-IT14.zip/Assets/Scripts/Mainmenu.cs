
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections;
using System.IO;

public class Mainmenu : MonoBehaviour
{
    [Header("Buttons")]
    [SerializeField] private Button startButton;
    [SerializeField] private Button loadButton;
    [SerializeField] private Button quitButton;

    [Header("Scene Names")]
    [SerializeField]
    private string characterSelectionScene =
        "CharacterSelection";

    [SerializeField]
    private string gameScene =
        "Target Zero - IT14";

    private string savePath;

    void Awake()
    {
        savePath = Path.Combine(
            Application.persistentDataPath,
            "savefile.json"
        );
    }

    void Start()
    {
        // Enable Load Game only if a save exists.
        if (loadButton != null)
        {
            loadButton.interactable = File.Exists(savePath);
        }

        // Configure controller navigation.
        SetupNavigation();

        // Automatically select Start Game.
        StartCoroutine(SelectFirstButton());
    }

    void SetupNavigation()
    {
        // Navigation for vertically arranged buttons.
        // Start -> Load -> Quit

        if (startButton == null || quitButton == null)
            return;

        bool canLoad = loadButton != null &&
                       loadButton.IsInteractable();

        Button middleButton = canLoad ? loadButton : null;

        Navigation startNav = startButton.navigation;
        startNav.mode = Navigation.Mode.Explicit;
        startNav.selectOnDown = middleButton != null
            ? middleButton : quitButton;
        startNav.selectOnUp = quitButton;
        startButton.navigation = startNav;

        Navigation quitNav = quitButton.navigation;
        quitNav.mode = Navigation.Mode.Explicit;
        quitNav.selectOnUp = middleButton != null
            ? middleButton : startButton;
        quitNav.selectOnDown = startButton;
        quitButton.navigation = quitNav;

        if (loadButton != null)
        {
            Navigation loadNav = loadButton.navigation;
            loadNav.mode = Navigation.Mode.Explicit;
            loadNav.selectOnUp = startButton;
            loadNav.selectOnDown = quitButton;
            loadButton.navigation = loadNav;
        }
    }

    IEnumerator SelectFirstButton()
    {
        yield return null;

        if (EventSystem.current == null)
            yield break;

        Button firstButton = startButton;

        if (firstButton == null || !firstButton.IsInteractable())
        {
            if (loadButton != null && loadButton.IsInteractable())
                firstButton = loadButton;
            else
                firstButton = quitButton;
        }

        if (firstButton != null && firstButton.IsInteractable())
        {
            EventSystem.current.SetSelectedGameObject(null);

            EventSystem.current.SetSelectedGameObject(
                firstButton.gameObject
            );
        }
    }

    public void PlayGame()
    {
        Debug.Log("Start Game Clicked!");

        SceneManager.LoadScene(characterSelectionScene);
    }

    public void LoadGame()
    {
        if (!File.Exists(savePath))
        {
            Debug.LogWarning("No saved game found!");
            return;
        }

        SaveLoadManager.LoadOnStart = true;

        SceneManager.LoadScene(gameScene);
    }

    public void QuitGame()
    {
        Debug.Log("Quit Game Clicked!");

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}


using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class UIButtonBlink : MonoBehaviour,
    IPointerEnterHandler,
    IPointerExitHandler,
    ISelectHandler,
    IDeselectHandler
{
    [Header("Blink Settings")]
    public float blinkSpeed = 4f;

    public Color normalColor = Color.white;
    public Color blinkColor = new Color(0.55f, 0.85f, 1f, 1f);

    private Image buttonImage;
    private bool isHovered;
    private bool isSelected;

    void Awake()
    {
        buttonImage = GetComponent<Image>();
    }

    void Update()
    {
        if (buttonImage == null)
            return;

        if (isHovered || isSelected)
        {
            float blink = (Mathf.Sin(Time.unscaledTime
                * blinkSpeed) + 1f) / 2f;

            buttonImage.color = Color.Lerp(
                normalColor,
                blinkColor,
                blink
            );
        }
        else
        {
            buttonImage.color = normalColor;
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        isHovered = true;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        isHovered = false;
    }

    public void OnSelect(BaseEventData eventData)
    {
        isSelected = true;
    }

    public void OnDeselect(BaseEventData eventData)
    {
        isSelected = false;
    }

    void OnDisable()
    {
        isHovered = false;
        isSelected = false;

        if (buttonImage != null)
            buttonImage.color = normalColor;
    }
}

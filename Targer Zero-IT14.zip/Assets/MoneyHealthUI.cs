using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MoneyHealthUI : MonoBehaviour
{
    public static MoneyHealthUI Instance;

    [Header("UI References")]
    [SerializeField] private TMP_Text moneyText;
    [SerializeField] private Slider healthSlider;

    [Header("Health Settings")]
    [Min(0f)]
    [SerializeField] private float healthLossAmount = 10f;

    [Min(1f)]
    [SerializeField] private float healthInterval = 60f;

    [Header("Editor Testing Mode")]
    [Tooltip("When enabled, each Play in Unity Editor starts with 500 money, full health, and fresh NPC allowances.")]
    [SerializeField] private bool editorTestingMode = true;

    [Header("Game Over")]
    [SerializeField] private GameObject gameOverPanel;

    private bool isGameOver;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Debug.LogError(
                "More than one MoneyHealthUI exists. " +
                "Keep only one active component.",
                this
            );

            enabled = false;
            return;
        }

        Instance = this;

        StudentSaveSystem.Load();

#if UNITY_EDITOR
        if (editorTestingMode)
        {
        // Start fresh during Unity Editor testing.
        // Keep the selected Boy or Girl.
        StudentSaveSystem.Data.money = 500;
        StudentSaveSystem.Data.health = 100f;

        StudentSaveSystem.Data.secondsUntilHealthLoss =
            Mathf.Max(1f, healthInterval);

        StudentSaveSystem.Data.claimedNPCs.Clear();

        StudentSaveSystem.Save();

        Debug.Log(
            "TEST START: Money ₱500, Health 100%, " +
            "NPC allowances reset."
        );
        }
#endif

        isGameOver = false;
    }

    private void Start()
    {
        if (gameOverPanel != null)
            gameOverPanel.SetActive(false);

        if (healthSlider != null)
        {
            healthSlider.minValue = 0f;
            healthSlider.maxValue = 100f;
            healthSlider.interactable = false;
        }

        UpdateUI();

        if (StudentSaveSystem.Data.money <= 0 ||
            StudentSaveSystem.Data.health <= 0f)
        {
            GameOver();
        }
    }

    private void Update()
    {
        if (isGameOver)
            return;

        StudentSaveSystem.Data.secondsUntilHealthLoss -=
            Time.unscaledDeltaTime;

        if (StudentSaveSystem.Data.secondsUntilHealthLoss <= 0f)
        {
            StudentSaveSystem.Data.secondsUntilHealthLoss =
                Mathf.Max(1f, healthInterval);

            ChangeHealth(-healthLossAmount);
        }
    }

    public void UpdateUI()
    {
        if (StudentSaveSystem.Data == null)
            return;

        if (moneyText != null)
        {
            moneyText.text =
                "Money: ₱" + StudentSaveSystem.Data.money;
        }

        if (healthSlider != null)
        {
            healthSlider.value =
                StudentSaveSystem.Data.health;
        }
    }

    public void AddMoney(int amount)
    {
        TryAddMoney(amount);
    }

    public bool TryAddMoney(int amount)
    {
        if (isGameOver)
        {
            Debug.LogWarning(
                "Cannot receive money because the game is over."
            );

            return false;
        }

        if (amount <= 0)
        {
            Debug.LogWarning(
                "The money reward must be greater than zero."
            );

            return false;
        }

        StudentSaveSystem.Data.money += amount;

        UpdateUI();
        StudentSaveSystem.Save();

        Debug.Log(
            "Received ₱" + amount +
            " | Total money: ₱" +
            StudentSaveSystem.Data.money
        );

        return true;
    }

    public bool SpendMoney(int amount)
    {
        if (isGameOver || amount <= 0)
            return false;

        if (StudentSaveSystem.Data.money < amount)
        {
            Debug.Log("Not enough money!");
            return false;
        }

        StudentSaveSystem.Data.money -= amount;

        UpdateUI();
        StudentSaveSystem.Save();

        if (StudentSaveSystem.Data.money <= 0)
            GameOver();

        return true;
    }

    public void ChangeHealth(float amount)
    {
        if (isGameOver)
            return;

        StudentSaveSystem.Data.health = Mathf.Clamp(
            StudentSaveSystem.Data.health + amount,
            0f,
            100f
        );

        UpdateUI();
        StudentSaveSystem.Save();

        if (StudentSaveSystem.Data.health <= 0f)
            GameOver();
    }

    public bool BuyFood(int price, float healthRecovery)
    {
        if (isGameOver || price <= 0 || healthRecovery <= 0f)
            return false;

        if (StudentSaveSystem.Data.money < price)
        {
            Debug.Log("Not enough money to buy food!");
            return false;
        }

        // Complete the purchase before checking Game Over.
        StudentSaveSystem.Data.money -= price;

        StudentSaveSystem.Data.health = Mathf.Clamp(
            StudentSaveSystem.Data.health + healthRecovery,
            0f,
            100f
        );

        UpdateUI();
        StudentSaveSystem.Save();

        Debug.Log(
            "Food purchased! Money: ₱" +
            StudentSaveSystem.Data.money +
            " | Health: " +
            StudentSaveSystem.Data.health
        );

        if (StudentSaveSystem.Data.money <= 0)
            GameOver();

        return true;
    }

    private void GameOver()
    {
        if (isGameOver)
            return;

        isGameOver = true;

        UpdateUI();
        StudentSaveSystem.Save();

        if (gameOverPanel != null)
            gameOverPanel.SetActive(true);

        Debug.Log(
            StudentSaveSystem.Data.money <= 0
                ? "GAME OVER! Your money reached ₱0."
                : "GAME OVER! Your health reached 0%."
        );
    }

    private void OnApplicationPause(bool paused)
    {
        if (paused && Instance == this)
            StudentSaveSystem.Save();
    }

    private void OnApplicationQuit()
    {
        if (Instance == this)
            StudentSaveSystem.Save();
    }

    private void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }
}
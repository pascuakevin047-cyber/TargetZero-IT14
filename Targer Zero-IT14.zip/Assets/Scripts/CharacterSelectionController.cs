
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections;

public class CharacterSelectionController : MonoBehaviour
{
    [Header("Game Scene")]
    [SerializeField]
    private string gameScene = "Target Zero - IT14";

    [Header("Character Buttons")]
    [SerializeField] private Button boyButton;
    [SerializeField] private Button girlButton;

    [Header("Character Animators")]
    [SerializeField] private Animator boyAnimator;
    [SerializeField] private Animator girlAnimator;

    private GameObject lastSelected;

    void Start()
    {
        StartCoroutine(SelectDefaultCharacter());
    }

    IEnumerator SelectDefaultCharacter()
    {
        yield return null;

        if (EventSystem.current != null && boyButton != null)
        {
            EventSystem.current.SetSelectedGameObject(null);
            EventSystem.current.SetSelectedGameObject(
                boyButton.gameObject
            );
        }
    }

    void Update()
    {
        if (EventSystem.current == null)
            return;

        GameObject selected =
            EventSystem.current.currentSelectedGameObject;

        if (selected == lastSelected)
            return;

        lastSelected = selected;

        bool boySelected =
            boyButton != null &&
            selected == boyButton.gameObject;

        bool girlSelected =
            girlButton != null &&
            selected == girlButton.gameObject;

        if (boyAnimator != null)
            boyAnimator.SetBool("IsSelected", boySelected);

        if (girlAnimator != null)
            girlAnimator.SetBool("IsSelected", girlSelected);
    }

    public void SelectBoy()
    {
        GameSession.SaveCharacter("Boy");
        SceneManager.LoadScene(gameScene);
    }

    public void SelectGirl()
    {
        GameSession.SaveCharacter("Girl");
        SceneManager.LoadScene(gameScene);
    }
}

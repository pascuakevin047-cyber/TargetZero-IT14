using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;

// Place on a vendor GameObject with a trigger Collider2D.
[RequireComponent(typeof(Collider2D))]
public class FoodVendor : MonoBehaviour
{
    [SerializeField] private string vendorName = "Food Vendor";
    private static readonly HashSet<FoodVendor> Vendors = new HashSet<FoodVendor>();
    private bool waitForInteractionRelease;
    private bool requirePlayerToLeaveBeforeTalking;
    private int nearbyColliders;
    private bool isTalking;
    private int dialogueStep;
    private bool shopOpen;
    private readonly int[] quantities = new int[6];
    private readonly string[] names = { "Rice Meal", "Sandwich", "Burger", "Water", "Juice", "Milk" };
    private readonly int[] prices = { 65, 35, 55, 15, 25, 30 };
    private readonly float[] healing = { 20, 12, 18, 4, 8, 10 };
    private readonly string[] iconFiles = { "rice", "sandwich", "burger", "water", "juice", "milk" };
    private Texture2D[] icons;
    private GUIStyle titleStyle, bodyStyle, buttonStyle, itemStyle;
    private string notice = "";
    private Vector2 scroll;
    public static bool AnyInteractionOpen { get; private set; }
    private int selectedControl; // 0..11: item minus/plus, 12: Close, 13: Buy
    private bool previousVertical, previousHorizontal;
    private bool ignoreSubmitUntilRelease;


    private void OnEnable() { Vendors.Add(this); }

    private void Awake()
    {
        GetComponent<Collider2D>().isTrigger = true;
        icons = new Texture2D[iconFiles.Length];
        for (int i = 0; i < icons.Length; i++) icons[i] = Resources.Load<Texture2D>("VendorIcons/" + iconFiles[i]);
    }

    private bool IsPlayer(Collider2D other)
    {
        return other.CompareTag("Player") || (other.attachedRigidbody != null && other.attachedRigidbody.CompareTag("Player")) || other.transform.root.CompareTag("Player");
    }

    private void OnTriggerEnter2D(Collider2D other) { if (IsPlayer(other)) nearbyColliders++; }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (!IsPlayer(other)) return;
        nearbyColliders = Mathf.Max(0, nearbyColliders - 1);
        if (nearbyColliders == 0) requirePlayerToLeaveBeforeTalking = false;
        // Keep the menu open if the player drifts outside the trigger while shopping.
    }

    private void Update()
    {
        bool e = Keyboard.current != null && Keyboard.current.eKey.wasPressedThisFrame;
        bool pad = Gamepad.current != null && Gamepad.current.buttonSouth.wasPressedThisFrame;
        if (waitForInteractionRelease)
        {
            bool stillHeld = (Keyboard.current != null && Keyboard.current.eKey.isPressed) ||
                             (Gamepad.current != null && Gamepad.current.buttonSouth.isPressed);
            if (stillHeld) return;
            waitForInteractionRelease = false;
        }
        if (shopOpen) HandleShopController();
        if (e || (pad && !shopOpen))
        {
            if (shopOpen) return;
            if (isTalking) AdvanceDialogue();
            else if (!requirePlayerToLeaveBeforeTalking && nearbyColliders > 0 && (DialogueUI.Instance == null || !DialogueUI.Instance.IsOpen()))
            {
                isTalking = true;
                AnyInteractionOpen = true;
                dialogueStep = 0;
            }
        }
        if (shopOpen && Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame) CloseShop();
        if (shopOpen && Gamepad.current != null && Gamepad.current.buttonEast.wasPressedThisFrame) CloseShop();
    }

    private void AdvanceDialogue()
    {
        dialogueStep++;
        if (dialogueStep >= 3)
        {
            isTalking = false;
            shopOpen = true;
            AnyInteractionOpen = true;
            selectedControl = 1;
            ignoreSubmitUntilRelease = true;
            notice = "D-pad/stick: navigate | Cross: select | Circle: close";
        }
    }

    private static void CloseAllVendorInteractions()
    {
        // Close all vendor instances, including accidental duplicates in the scene.
        foreach (FoodVendor vendor in new List<FoodVendor>(Vendors))
        {
            if (vendor != null) vendor.CloseShop();
        }
    }

    private void CloseShop()
    {
        isTalking = false;
        shopOpen = false;
        AnyInteractionOpen = false;
        dialogueStep = 0;
        notice = "";
        previousVertical = false;
        previousHorizontal = false;
        ignoreSubmitUntilRelease = false;
        waitForInteractionRelease = true;
        requirePlayerToLeaveBeforeTalking = true;
        for (int i = 0; i < quantities.Length; i++) quantities[i] = 0;
    }

    private void HandleShopController()
    {
        Gamepad pad = Gamepad.current;
        if (pad == null) return;
        if (ignoreSubmitUntilRelease)
        {
            if (!pad.buttonSouth.isPressed) ignoreSubmitUntilRelease = false;
            return;
        }
        Vector2 direction = pad.dpad.ReadValue();
        if (direction.sqrMagnitude < 0.2f) direction = pad.leftStick.ReadValue();
        bool vertical = Mathf.Abs(direction.y) > 0.55f;
        bool horizontal = Mathf.Abs(direction.x) > 0.55f;
        if (vertical && !previousVertical)
        {
            int row = selectedControl < 12 ? selectedControl / 2 : 6;
            int column = selectedControl < 12 ? selectedControl % 2 : selectedControl - 12;
            row = Mathf.Clamp(row + (direction.y < 0 ? 1 : -1), 0, 6);
            selectedControl = row == 6 ? 12 + column : row * 2 + column;
        }
        if (horizontal && !previousHorizontal)
        {
            if (selectedControl < 12) selectedControl = selectedControl / 2 * 2 + (direction.x > 0 ? 1 : 0);
            else selectedControl = direction.x > 0 ? 13 : 12;
        }
        previousVertical = vertical;
        previousHorizontal = horizontal;
        if (pad.buttonSouth.wasPressedThisFrame)
        {
            if (selectedControl < 12)
            {
                int index = selectedControl / 2;
                quantities[index] = Mathf.Clamp(quantities[index] + (selectedControl % 2 == 1 ? 1 : -1), 0, 99);
            }
            else if (selectedControl == 12) CloseShop();
            else Purchase();
        }
    }

    private string Highlight(int index, string label)
    {
        return Gamepad.current != null && selectedControl == index ? "▶ " + label : label;
    }

    private int Total()
    {
        int sum = 0;
        for (int i = 0; i < quantities.Length; i++) sum += quantities[i] * prices[i];
        return sum;
    }

    private void Purchase()
    {
        int total = Total();
        if (total <= 0) { notice = "Select at least one item."; return; }
        if (MoneyHealthUI.Instance == null || StudentSaveSystem.Data == null) { notice = "MoneyHealthUI is missing in this scene."; return; }
        if (StudentSaveSystem.Data.money < total) { notice = "Not enough money! Remove items or earn more allowance."; return; }
        float recovery = 0;
        for (int i = 0; i < quantities.Length; i++) recovery += quantities[i] * healing[i];
        // One atomic purchase: no partial deduction or healing.
        if (MoneyHealthUI.Instance.BuyFood(total, recovery))
        {
            // Successful purchase finishes the entire vendor interaction immediately.
            // This also releases the movement lock for keyboard and controller.
            CloseAllVendorInteractions();
        }
        else notice = "Purchase could not be completed.";
    }

    private void EnsureStyles()
    {
        if (titleStyle != null) return;
        titleStyle = new GUIStyle(GUI.skin.label) { normal = { textColor = new Color32(35, 24, 27, 255) }, fontSize = 22, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter, wordWrap = true };
        bodyStyle = new GUIStyle(GUI.skin.label) { normal = { textColor = new Color32(35, 24, 27, 255) }, fontSize = 16, alignment = TextAnchor.MiddleLeft, wordWrap = true };
        itemStyle = new GUIStyle(GUI.skin.label) { normal = { textColor = new Color32(35, 24, 27, 255) }, fontSize = 15, alignment = TextAnchor.MiddleLeft };
        buttonStyle = new GUIStyle(GUI.skin.button) { fontSize = 18, fontStyle = FontStyle.Bold };
    }

    private void OnGUI()
    {
        if (!isTalking && !shopOpen && (nearbyColliders <= 0 || requirePlayerToLeaveBeforeTalking)) return;
        EnsureStyles();
        // UI is authored at 960x650 and scaled to the Game view, independent of world scale.
        float scale = Mathf.Min(Screen.width / 960f, Screen.height / 650f);
        scale = Mathf.Max(0.55f, scale);
        Matrix4x4 oldMatrix = GUI.matrix;
        GUI.matrix = Matrix4x4.TRS(new Vector3((Screen.width - 960 * scale) / 2f, (Screen.height - 650 * scale) / 2f, 0), Quaternion.identity, new Vector3(scale, scale, 1));
        if (!isTalking && !shopOpen)
        {
            GUI.Box(new Rect(290, 550, 380, 50), "E / CROSS  -  TALK TO VENDOR", PixelUISkin.Panel);
        }
        else if (isTalking)
        {
            GUI.Box(new Rect(100, 410, 760, 180), "", PixelUISkin.Panel);
            string speaker = dialogueStep == 1 ? "Player" : vendorName;
            string line = dialogueStep == 0 ? "How can I help you?" : dialogueStep == 1 ? "Hmm, what food and drinks are you selling?" : "Here's our food and drinks menu!";
            GUI.Label(new Rect(125, 430, 710, 35), speaker, titleStyle);
            GUI.Label(new Rect(130, 475, 700, 45), line, bodyStyle);
            if (GUI.Button(new Rect(650, 535, 175, 42), dialogueStep == 2 ? "OPEN MENU" : "NEXT", PixelUISkin.Button)) AdvanceDialogue();
        }
        else if (shopOpen)
        {
            // The reference-style menu is laid out on a 960x650 virtual screen.
            // Pixel borders use 9-slice backgrounds so they remain crisp at any resolution.
            GUI.Box(new Rect(54, 10, 852, 630), "", PixelUISkin.Panel);
            GUI.Label(new Rect(78, 24, 804, 62), "FOOD & DRINKS MENU", PixelUISkin.Header);
            int money = StudentSaveSystem.Data == null ? 0 : StudentSaveSystem.Data.money;
            GUI.Label(new Rect(95, 92, 690, 28), "Your money: ₱" + money, bodyStyle);

            scroll = GUI.BeginScrollView(new Rect(88, 128, 792, 366), scroll,
                new Rect(0, 0, 765, names.Length * 60));
            for (int i = 0; i < names.Length; i++)
            {
                int y = i * 60;
                GUI.Box(new Rect(0, y, 760, 57), "", PixelUISkin.Row);
                if (icons[i] != null)
                    GUI.DrawTexture(new Rect(12, y + 7, 44, 44), icons[i], ScaleMode.ScaleToFit);
                GUI.Label(new Rect(67, y + 9, 180, 38), names[i], itemStyle);
                GUI.Label(new Rect(260, y + 9, 80, 38), "₱" + prices[i], itemStyle);
                GUI.Label(new Rect(352, y + 9, 115, 38), "+" + healing[i] + "% HP", itemStyle);
                if (GUI.Button(new Rect(490, y + 8, 58, 42), Highlight(i * 2, "−"),
                    PixelUISkin.ForControl(i * 2, selectedControl, Gamepad.current != null)))
                    quantities[i] = Mathf.Max(0, quantities[i] - 1);
                GUI.Box(new Rect(553, y + 8, 50, 42), quantities[i].ToString(), PixelUISkin.Count);
                if (GUI.Button(new Rect(608, y + 8, 58, 42), Highlight(i * 2 + 1, "+"),
                    PixelUISkin.ForControl(i * 2 + 1, selectedControl, Gamepad.current != null)))
                    quantities[i] = Mathf.Min(99, quantities[i] + 1);
            }
            GUI.EndScrollView();

            GUI.Label(new Rect(135, 498, 690, 34), "TOTAL TO PAY: ₱" + Total(), titleStyle);
            GUI.Label(new Rect(98, 531, 770, 22), notice, bodyStyle);
            if (GUI.Button(new Rect(98, 563, 286, 57), Highlight(12, "CLOSE"),
                PixelUISkin.ForControl(12, selectedControl, Gamepad.current != null)))
            {
                CloseAllVendorInteractions();
                GUI.matrix = oldMatrix;
                GUIUtility.ExitGUI();
            }
            GUI.enabled = Total() > 0;
            if (GUI.Button(new Rect(505, 563, 355, 57), Highlight(13, "BUY NOW  -  ₱" + Total()),
                PixelUISkin.ForControl(13, selectedControl, Gamepad.current != null)))
            {
                Purchase();
                if (!shopOpen)
                {
                    GUI.matrix = oldMatrix;
                    GUIUtility.ExitGUI();
                }
            }
            GUI.enabled = true;
        }
        GUI.matrix = oldMatrix;
    }

    private void OnDisable()
    {
        Vendors.Remove(this);
        nearbyColliders = 0;
        isTalking = false;
        shopOpen = false;
        AnyInteractionOpen = false;
    }
}

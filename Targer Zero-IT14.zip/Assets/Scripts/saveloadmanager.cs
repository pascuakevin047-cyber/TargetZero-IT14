using UnityEngine;
using System.IO;

public class SaveLoadManager : MonoBehaviour
{
    // Set by the main menu. If true, the game scene loads the save on start.
    public static bool LoadOnStart = false;

    private string SavePath => Application.persistentDataPath + "/savefile.json";

    void Start()
    {
        if (LoadOnStart)
        {
            LoadOnStart = false;
            LoadGame();
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F5))
            SaveGame();

        if (Input.GetKeyDown(KeyCode.F9))
            LoadGame();
    }

    public void SaveGame()
    {
        SaveData data = new SaveData();
        data.money = MoneyManager.Instance.GetMoney();
        data.playerX = GameObject.FindWithTag("Player").transform.position.x;
        data.playerY = GameObject.FindWithTag("Player").transform.position.y;

        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(SavePath, json);

        Debug.Log("Game Saved to: " + SavePath);
    }

    public void LoadGame()
    {
        if (File.Exists(SavePath))
        {
            string json = File.ReadAllText(SavePath);
            SaveData data = JsonUtility.FromJson<SaveData>(json);

            MoneyManager.Instance.SetMoney(data.money);

            Vector2 loadedPosition = new Vector2(data.playerX, data.playerY);
            GameObject.FindWithTag("Player").transform.position = loadedPosition;

            Debug.Log("Game Loaded!");
        }
        else
        {
            Debug.Log("No save file found.");
        }
    }
}
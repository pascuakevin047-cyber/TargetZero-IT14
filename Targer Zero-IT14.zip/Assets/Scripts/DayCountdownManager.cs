using UnityEngine;

// Automatically attached by SelectedCharacterSpawner to the chosen Boy/Girl.
// Counts down only during gameplay; pauses for NPC conversations and shopping.
public class DayCountdownManager : MonoBehaviour
{
    [Header("Day Settings")]
    [Min(1)] [SerializeField] private int totalDays = 7;
    [Min(1f)] [SerializeField] private float secondsPerDay = 60f;
    [SerializeField] private bool pauseDuringNPCInteractions = true;

    private Vector3 spawnPosition;
    private Rigidbody2D playerBody;
    private float timeRemaining;
    private int currentDay = 1;
    private bool finished;
    private bool configured;
    private GUIStyle timerStyle;
    private GUIStyle completedStyle;

    public int CurrentDay => currentDay;
    public float TimeRemaining => timeRemaining;

    public void SetSpawnPoint(Vector3 position)
    {
        spawnPosition = position;
        spawnPosition.z = transform.position.z;
        configured = true;
    }

    private void Awake()
    {
        playerBody = GetComponent<Rigidbody2D>();
        timeRemaining = secondsPerDay;
    }

    private void Update()
    {
        if (finished || !configured) return;
        if (pauseDuringNPCInteractions && PlayerInteractionLock.IsLocked) return;

        timeRemaining -= Time.deltaTime;
        if (timeRemaining <= 0f) EndDay();
    }

    private void EndDay()
    {
        timeRemaining = 0f;
        if (currentDay >= totalDays)
        {
            finished = true;
            Debug.Log("Week complete! Player money and health were preserved.");
            return;
        }

        currentDay++;
        RespawnWithoutResettingStats();
        timeRemaining = secondsPerDay;
        Debug.Log("Day " + currentDay + " started. Money and health preserved.");
    }

    private void RespawnWithoutResettingStats()
    {
        if (playerBody != null)
        {
            playerBody.linearVelocity = Vector2.zero;
            playerBody.position = new Vector2(spawnPosition.x, spawnPosition.y);
        }
        transform.position = spawnPosition;
        // Do not reload the scene, call StudentSaveSystem.Load(),
        // or change MoneyHealthUI / StudentSaveSystem.Data here.
    }

    private void OnGUI()
    {
        if (!configured) return;
        if (PlayerInteractionLock.IsLocked && !finished) return;
        if (timerStyle == null)
        {
            timerStyle = new GUIStyle(GUI.skin.box) {
                fontSize = 24, fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleCenter
            };
            completedStyle = new GUIStyle(GUI.skin.box) {
                fontSize = 27, fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleCenter, wordWrap = true
            };
        }

        float scale = Mathf.Max(0.6f, Mathf.Min(Screen.width / 960f, Screen.height / 540f));
        Matrix4x4 old = GUI.matrix;
        GUI.matrix = Matrix4x4.TRS(new Vector3((Screen.width - 960f * scale) / 2f,
            (Screen.height - 540f * scale) / 2f, 0f), Quaternion.identity,
            new Vector3(scale, scale, 1f));

        int seconds = Mathf.CeilToInt(timeRemaining);
        string timeText = (seconds / 60).ToString("00") + ":" + (seconds % 60).ToString("00");
        GUI.Box(new Rect(355, 8, 250, 56), "DAY " + currentDay + " / " + totalDays + "    " + timeText, PixelUISkin.Header);
        if (finished)
        {
            GUI.Box(new Rect(200, 190, 560, 135),
                "WEEK COMPLETE!\nYou finished all " + totalDays + " days!", PixelUISkin.Panel);
        }
        GUI.matrix = old;
    }
}

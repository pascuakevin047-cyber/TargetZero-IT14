using UnityEngine;

// Crisp nine-sliced pixel-art UI generated at runtime. No external fonts or image files needed.
public static class PixelUISkin
{
    private static GUIStyle panelStyle, rowStyle, buttonStyle, selectedStyle, headerStyle, buyStyle, countStyle;
    private static Texture2D MakeFrame(Color32 fill, Color32 dark, Color32 wood, Color32 gold, Color32 highlight)
    {
        const int n = 48;
        var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Point;
        tex.wrapMode = TextureWrapMode.Clamp;
        for (int y = 0; y < n; y++) for (int x = 0; x < n; x++)
        {
            int d = Mathf.Min(x, y, n - 1 - x, n - 1 - y);
            Color32 c = d < 2 ? dark : d < 5 ? wood : d < 7 ? dark : d < 11 ? gold : d < 13 ? highlight : fill;
            // Pixel-step corner cuts, not rounded or blurry borders.
            if ((x < 5 && y < 5) || (x >= n-5 && y < 5) ||
                (x < 5 && y >= n-5) || (x >= n-5 && y >= n-5)) c = dark;
            tex.SetPixel(x, y, c);
        }
        tex.Apply(false, false);
        return tex;
    }
    private static GUIStyle Style(Texture2D tex, int fontSize, TextAnchor alignment)
    {
        var style = new GUIStyle(GUI.skin.button);
        style.normal.background = tex;
        style.hover.background = tex;
        style.active.background = tex;
        style.focused.background = tex;
        style.onNormal.background = tex;
        style.normal.textColor = Color.black;
        style.hover.textColor = Color.black;
        style.active.textColor = Color.black;
        style.focused.textColor = Color.black;
        style.fontSize = fontSize;
        style.fontStyle = FontStyle.Bold;
        style.alignment = alignment;
        style.wordWrap = false;
        style.border = new RectOffset(15, 15, 15, 15);
        style.padding = new RectOffset(12, 12, 8, 8);
        return style;
    }
    private static void Ensure()
    {
        if (panelStyle != null) return;
        Color32 ink = new Color32(36, 22, 21, 255);
        Color32 wood = new Color32(142, 73, 43, 255);
        Color32 gold = new Color32(246, 172, 95, 255);
        Color32 light = new Color32(255, 216, 148, 255);
        panelStyle = Style(MakeFrame(new Color32(255, 246, 239, 255), ink, wood, gold, light), 16, TextAnchor.MiddleCenter);
        rowStyle = Style(MakeFrame(new Color32(255, 249, 244, 255), ink, new Color32(105, 64, 48, 255), new Color32(246, 221, 202, 255), new Color32(255, 251, 246, 255)), 16, TextAnchor.MiddleLeft);
        buttonStyle = Style(MakeFrame(new Color32(251, 206, 162, 255), ink, wood, new Color32(239, 162, 101, 255), light), 18, TextAnchor.MiddleCenter);
        selectedStyle = Style(MakeFrame(new Color32(255, 203, 90, 255), ink, wood, new Color32(255, 170, 54, 255), new Color32(255, 238, 148, 255)), 18, TextAnchor.MiddleCenter);
        buyStyle = Style(MakeFrame(new Color32(255, 198, 69, 255), ink, wood, new Color32(249, 159, 55, 255), new Color32(255, 228, 122, 255)), 20, TextAnchor.MiddleCenter);
        headerStyle = Style(MakeFrame(new Color32(255, 245, 246, 255), ink, wood, gold, light), 23, TextAnchor.MiddleCenter);
        countStyle = Style(MakeFrame(new Color32(255, 250, 242, 255), ink, new Color32(154, 105, 67, 255), new Color32(248, 228, 195, 255), new Color32(255, 255, 250, 255)), 16, TextAnchor.MiddleCenter);
    }
    public static GUIStyle Panel { get { Ensure(); return panelStyle; } }
    public static GUIStyle Row { get { Ensure(); return rowStyle; } }
    public static GUIStyle Button { get { Ensure(); return buttonStyle; } }
    public static GUIStyle Selected { get { Ensure(); return selectedStyle; } }
    public static GUIStyle Header { get { Ensure(); return headerStyle; } }
    public static GUIStyle Buy { get { Ensure(); return buyStyle; } }
    public static GUIStyle Count { get { Ensure(); return countStyle; } }
    public static GUIStyle ForControl(int index, int selectedIndex, bool gamepad)
    {
        Ensure();
        return gamepad && index == selectedIndex ? selectedStyle : index == 13 ? buyStyle : buttonStyle;
    }
}
